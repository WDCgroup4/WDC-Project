var path = require("path");
var cookieParser = require("cookie-parser");
var logger = require("morgan");
var mysql = require("mysql");
const bodyParser = require("body-parser");
const crypto = require("crypto");
var session = require("express-session");
var MySQLStore = require("express-mysql-session")(session);
const { OAuth2Client } = require("google-auth-library");
var express = require('express');
var router = express.Router();


var dbconnection = mysql.createConnection({
    host: "127.0.0.1",
    database: "Project",
  });

function validatePassword(password, hash, salt) {
    var EnteredHash = crypto
      .pbkdf2Sync(password, salt, 10000, 60, "sha512")
      .toString("hex");
    return hash === EnteredHash;
  }

  function SaltAndHashPassword(password) {
    var salt = crypto.randomBytes(32).toString("hex");
    var genhash = crypto
      .pbkdf2Sync(password, salt, 10000, 60, "sha512")
      .toString("hex");
    return { salt: salt, hash: genhash };
  }


  function userExists(req, res, next) {
    dbconnection.query(
      "SELECT * from user where email=?",
      [req.body.email],
      function (error, results, fields) {
        console.log(results);
        if (error) {
          console.log(error);
          res.status(401);
          res.send();
        } else if (results.length >= 1 && results.google_token == 1) {
          res.status(403);
          res.send(
            "Login With Google Already exists. Please Login with your Google account"
          );
        } else if (results.length >= 1 && results.google_token == null) {
          res.status(403);
          res.send("user already exists");
        } else {
          next();
        }
      }
    );
  }



  router.post("/register", userExists, (req, res, next) => {
    console.log("inside post");
    console.log(req.body.password);
    let Salthash = SaltAndHashPassword(req.body.password);
    let newsalt = Salthash.salt;
    let newhash = Salthash.hash;

    dbconnection.query(
        "INSERT into user(Full_name, Email, hash, salt, Admin_permission, google_token) values(?, ?, ?, ?,0, null)",
      [req.body.full_name, req.body.email, newhash, newsalt],
      function (error, results, fields) {
        console.log(results);
        console
        if (error) {
          res.status(403);
          res.send("Error Occured");
          console.log(error);
        } else {
          console.log("successful");
          dbconnection.query("SELECT * from user where email=?", [req.body.email], (error,results,fields)=>{
            req.session.user = results[0].UserId;
            console.log(req.session);
            res.status(200)
            res.send();
          })

        }
      }
    );
  });
  let google_name = "";
  let google_email = "";
  let google_stat = 0;

  router.post("/google", (req, res, next) => {
    let CLIENT_ID =
      "839931049784-gq6gr6ftb80ai5qvdb42lhgv4qptjfcb.apps.googleusercontent.com";
    const client = new OAuth2Client(CLIENT_ID);
    async function verify() {
      const ticket = await client.verifyIdToken({
        idToken: req.body.credential,
        audience: CLIENT_ID,
      });
      const payload = ticket.getPayload();
      const userid = payload["sub"];
      console.log(userid);
      google_email = payload["email"];

      google_name = payload["name"];

      dbconnection.query(
        "SELECT * from user where email=?",
        [google_email],
        function (error, results, fields) {
          console.log(results);
          if (error) {
            console.log(error);
            res.status(401);
            res.send();
          } else if (results.length == 0) {
            dbconnection.query(
              "INSERT into user(Full_name, Email, hash, salt, Admin_permission, google_token) values(?, ?, 0, 0, 0, 1)",
              [google_name, google_email],
              function (error, results, fields) {
                  console.log(results);
                  console.log(fields);
                if (error) {
                  res.status(403);
                  res.send("Error Occured");
                  console.log(error);
                } else {
                  console.log("successful");
                  dbconnection.query("SELECT * from user where email=?", [google_email], (error,results,fields)=>{
                    req.session.user = results[0].UserId;
                    console.log(req.session);
                    res.redirect("/");
                  })

                }
              }
            );
          }
          else{
            req.session.user = results[0].UserId;
            console.log(results[0].UserId);
            console.log(req.session);
            res.redirect("/");
          }
        }
      );
    }

    verify().catch(console.error);


  });
  router.post("/login",function (req, res) {
    dbconnection.query(
      "SELECT * FROM user WHERE email = ? ",
      [req.body.email],
      function (error, results, fields) {
        if (error) {
          return done(error);
        }
        if (results.length == 0) {
          res.status(500);
          res.send("Account not found");
        }
        const PasswordAuth = validatePassword(req.body.password,results[0].hash,results[0].salt);
        if (PasswordAuth) {
          req.session.user = results[0].UserId;
          console.log(results.UserId);
          console.log(req.session);
          res.redirect("/");
        } else {
          return done(null, false);
        }
      }
    );
  }
  );

  router.get("/isloggedin", (req,res)=>{
  if (req.session.user==null){
    res.status(401);
  }
  dbconnection.query("select * from user where UserId=?",[req.session.user], function(error, results, fields){
    if (error){
      console.log(error);
      res.status(500);
      res.send("Error Occured");
    }
    else if (results.length>0){
      res.status(200);
      res.send("Logged in");
    }
    else{
      res.status(401);
      res.send("Not Logged in");
    }
  });
  });

router.post('/logout', function(req, res){
    if(req.session.user==null){
        res.status(417);
        res.send("Not logged in  ");
    }
    req.session.destroy();
    res.status(200);
    res.send();
})

  module.exports = router;