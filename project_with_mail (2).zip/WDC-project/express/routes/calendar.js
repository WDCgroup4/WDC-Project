var express = require('express');
var router = express.Router();
var axios = require('axios');

client_secret = {
  "web": {
    "client_id": "839931049784-gq6gr6ftb80ai5qvdb42lhgv4qptjfcb.apps.googleusercontent.com",
    "project_id": "maps-api-350702",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_secret": "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",
    "redirect_uris": [
      "https://priyanshuppal-code50-60973845-vx7p4px9fwpgv-3000.githubpreview.dev/auth/google",
      "https://developers.google.com/oauthplayground"
    ],
    "javascript_origins": [
      "http://localhost:3000",
      "https://priyanshuppal-code50-60973845-vx7p4px9fwpgv-3000.githubpreview.dev"
    ]
  },
  "refresh_token": "1//04Uy86s9hUPaECgYIARAAGAQSNwF-L9Iro6idUY54-vWrZwCI4X6rJTyyg0E23dDc8WTBcAcD200gxyuNQoQ9JzgqHqTRgt6LmAg",
  "access_token": "ya29.a0ARrdaM8oO6EpFI1iVC_ftmMNpnTd_DRpo0EJ9w1xiqjPsMuPyFujvRYmvIJ7diNRnakN_O7xKIi6JZWNptBdv-KTGf-tQ976fFHryhcjLY6U8kw8UrPjNYd7fYlT3-w9Te-l1IsZzXk6SNuorEneGvV10tLq"
}

router.get('/events', async function(req, res, next) {
  const response = await axios.get("https://www.googleapis.com/calendar/v3/calendars/wdcgroup4@gmail.com/events", {
    headers: {
      Accept: 'application/json',
      Authorization: 'Bearer ya29.a0ARrdaM8oO6EpFI1iVC_ftmMNpnTd_DRpo0EJ9w1xiqjPsMuPyFujvRYmvIJ7diNRnakN_O7xKIi6JZWNptBdv-KTGf-tQ976fFHryhcjLY6U8kw8UrPjNYd7fYlT3-w9Te-l1IsZzXk6SNuorEneGvV10tLq'
    }
  });
  res.send(JSON.stringify(response.data));
});

module.exports = router;

