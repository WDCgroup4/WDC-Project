var express = require('express');
var nodemailer = require('nodemailer');
var router = express.Router();
var mysql = require("mysql");

var dbconnection = mysql.createConnection({
  host: "127.0.0.1",
  database: "Project",
});

router.post('/send', function (req, res) {
  dbconnection.query("select email from user where UserId=?", [req.session.user],
  function(error, results, fields){
    if (error){
      console.log(error);
      res.status(500);
      res.send("Error Occured");
    }
    else if (results.length>0){
      const to = results[0].email;
      // TODO: Change to real email in the final version
      // TODO: To test more --> https://ethereal.email/
      const transporter = nodemailer.createTransport({
        host: 'smtp.ethereal.email',
        port: 587,
        auth: {
            user: 'bridgette.franecki72@ethereal.email',
            pass: '3wvy13sQGYpxK5Gx3K'
        }
      });
      const mailOptions = {
        from: '"EventsAlive" <info@dkm.com>',
        to: to,
        subject: 'Placeholder email', // TODO: Send depends on type of noti
        text: `The event "${req.body.event_name}" on ${req.body.date} `
                + `is successfully created :) at`,
      };

      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.log(error);
        }
        console.log("Message sent: %s", info.messageId);
        // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

        // Preview only available when sending through an Ethereal account
        console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
        // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
        res.redirect('/');
      });
    }
    else{
      res.status(401);
      res.send("Not Logged in");
    }
  });
});

module.exports = router;
