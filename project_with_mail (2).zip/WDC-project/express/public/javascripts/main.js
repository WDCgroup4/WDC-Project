var vueinst = new Vue({
  el: "#app",
  data: {
    login_status: false,
    login_window: false,
    register_window: false,
    manage_window: false,

    login_email: "",
    login_password: "",

    is_name_null:false,
    show_error:false,
    show_error_reg:false,
    entered_loc:"",
    register_email: "",
    reg_password: "",
    reg_password_confirm: "",
    reg_password_valid: true,
    reg_name_valid:true
  },
  computed: {
    isLoginEmail: function () {
        return /^[^\s@]+@([^\s@.]+\.)+[^\s@.]+$/.test(this.login_email);
    },
    isRegisterEmail: function () {
      return /^[^\s@]+@([^\s@.]+\.)+[^\s@.]+$/.test(this.register_email);
  }
  },
});

document.addEventListener('DOMContentLoaded', logincheck());

function initAutocomplete() {
  // let address = GetLatlong();

  // var geocoder = new google.maps.Geocoder();

  // geocoder.geocode(
  //   {
  //     address: address,
  //   },
  //   function (results, status) {
  //     if (status == google.maps.GeocoderStatus.OK) {
  //       var latitude = results[0].geometry.location.lat();
  //       var longitude = results[0].geometry.location.lng();
  //       console.log(latitude);
  //       console.log(longitude);
  //     }
  //   }
  // );

  let auto = document.getElementById("autocomplete");
  new google.maps.places.Autocomplete(auto);
  document.autocomplete.addEventListener("place_changed", onChange());
}

function onChange() {
  var place = autocomplete.getPlace();
  if (!place.geometry) {
    document.getElementById("autocomplete").placeholder = "Enter a place";
  } else {
    document.getElementById("autocomplete").innerHTML = place.name;
  }
}
const client = google.accounts.oauth2.initCodeClient({
  client_id:
    "839931049784-gq6gr6ftb80ai5qvdb42lhgv4qptjfcb.apps.googleusercontent.com",
  scope: "https://www.googleapis.com/auth/calendar.readonly",
  ux_mode: "popup",
  callback: (response) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", code_receiver_uri, true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    // Set custom header for CRSF
    xhr.setRequestHeader("X-Requested-With", "XmlHttpRequest");
    xhr.onload = function () {
      console.log("Auth code response: " + xhr.responseText);
    };
    xhr.send("code=" + code);
  },
});

function login() {

  if (vueinst.isLoginEmail==false) {
    vueinst.show_error=true;
    return;
  }
  else{
    vueinst.show_error=false;
  }
  let url = "/auth/login";
  let entered_email = document.getElementById("login-email").value;
  let entered_pass = document.getElementById("login-password").value;

  const toSend = {
    email: entered_email,
    password: entered_pass,
  };
  const jsoned = JSON.stringify(toSend);
  console.log(jsoned);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 401) {
      document.getElementById("error-success-log").innerHTML =
        "Incorrect Email or Password";
    }
    else if (this.readyState == 4 && this.status == 200){
      document.getElementById("error-success-log").innerHTML =
        "Login Successful";
      setTimeout(function () {
        location.reload();
    }, 1500);

    }
  };
  xhttp.open("POST", url, true);
  xhttp.setRequestHeader("Content-Type", "application/json");
  xhttp.send(jsoned);
}
function Register() {

  let url = "/auth/register";
  let entered_email = document.getElementById("register-email").value;
  let entered_pass = document.getElementById("register-password").value;
  let entered_name = document.getElementById("register-name").value;
  if (vueinst.isRegisterEmail==false) {
    vueinst.show_error_reg=true
    return;
  }
  else{
    vueinst.show_error_reg=false;
  }
  if (entered_name == "" || entered_name == null) {vueinst.is_name_null=true
  return}
  const toSend = {
    full_name: entered_name,
    email: entered_email,
    password: entered_pass,
  };
  const jsoned = JSON.stringify(toSend);
  console.log(jsoned);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("error-success-reg").innerHTML = "Account Created";
      setTimeout(function () {
        location.reload();
    }, 1500);
    } else {
      // document.getElementById("error-success-reg").innerHTML = this.responseText;
    }
  };
  xhttp.open("POST", url, true);
  xhttp.setRequestHeader("Content-Type", "application/json");
  xhttp.send(jsoned);
}
// function GetLatlong() {
//   url = "/getaddress";
//   xhttp = new XMLHttpRequest();
//   xhttp.onreadystatechange = function () {
//     if (this.readyState == 4 && this.status == 200) {
//       let address = this.responseText;
//     }
//   };
//   xhttp.open(GET, url, true);
//   xhttp.send();
//   return address;
// }
function logincheck() {
  let url="/auth/isloggedin";
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      vueinst.login_status=true;
      document.cookie = "SID=yes"
    }
    else if(this.readyState == 4 && this.status==401){
      vueinst.login_status=false;
      document.cookie = "SID="

    }
  };
  xhttp.open("GET", url, true);
  xhttp.send();

}
function logout(){
  let url="/auth/logout";
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      vueinst.login_status=false;
      document.cookie = "SID="
    }
    else if(this.readyState == 4 && this.status==401){
      vueinst.login_status=true;
      document.cookie = "SID=failed"

    }
  };
  xhttp.open("POST", url, true);
  xhttp.send();
}


function Create_Event(){
  let url="/create_event"
  let entered_event_name=document.getElementById('register_event').value;
  let entered_location=vueinst.entered_loc;
  let entered_date=document.getElementById('register_date').value;
  let entered_time=document.getElementById('register_time').value;
  let entered_desc=document.getElementById('register_descrip').value;
  let today = new Date();

  const toSend={
      event_name: entered_event_name,
      location: entered_location,
      date: entered_date,
      time: entered_time,
      desc: entered_desc
    }
    const jsoned=JSON.stringify(toSend);
    console.log(jsoned);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      console.log("Success added an Event");
      sendEmail(toSend);
  }

};
  xhttp.open("POST", url, true);
  xhttp.setRequestHeader("Content-Type", "application/json");
  xhttp.send(jsoned);
}

function sendEmail(toSend) {
  console.log("Sending email");
  let url="/mail/send";

  // TODO: Add checkbox options in the request!
  const jsoned=JSON.stringify(toSend);
  console.log(jsoned);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    console.log(this.readyState, this.status);
    if (this.readyState == 4 && this.status == 200) {
      console.log("Successfully sent email notification");
    }
  };
  xhttp.open("POST", url, true);
  xhttp.setRequestHeader("Content-Type", "application/json");
  xhttp.send(jsoned);
}


function ShowEvents() {
  console.log('This is not called?');
  let url = "/showEvents";
  let today = new Date();
  let entered_date = document.getElementById("register_date").value;
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
       let events = JSON.parse(this.responseText);
       console.log(events);
       for ( let list of events ){
        var event_element = document.createElement("li");
        event_element.innerHTML = "EventID: " + list["EventID"] + ", " + "Event name: " + list["Event_name"] + ", " +
        "HostID: " + list["HostID"] + ", " + "Time: " + list["The_time"].getHours() + ":" + list["The_time"].getMinutes() + " at " +
        list["Address_event"] + "." + " Description for the event: " + list["Address_event"];
        if (entered_date.getTime() <= today.getTime() ){
          document.getElementById("past-event").appendChild(event_element);
        }
        else if(entered_date.getTime() > today.getTime() ){
          document.getElementById("future-event").appendChild(event_element);
        }
      }
    }
  };
  xhttp.open("GET", url, true);
  xhttp.send();
}
