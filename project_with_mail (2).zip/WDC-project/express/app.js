require("dotenv").config();
var express = require("express");
var path = require("path");
var cookieParser = require("cookie-parser");
var logger = require("morgan");
var calendarRouter = require("./routes/calendar");
var authRouter = require("./routes/auth");
var mailRouter = require("./routes/mail");
var mysql = require("mysql");
const bodyParser = require("body-parser");
const crypto = require("crypto");
var session = require("express-session");
var MySQLStore = require("express-mysql-session")(session);
var app = express();

var dbconnection = mysql.createConnection({
  host: "127.0.0.1",
  database: "Project",
});
var dbconnectionpool = mysql.createPool({
  host: "127.0.0.1",
  database: "Project",
});
dbconnection.connect((err) => {
  if (!err) {
    console.log("Connected!!");
  } else if (err) {
    console.log(err);
    console.log("Not Connected :(");
  }
});

app.use(
  session({
    secret: "session_cookie_secret",
    store: new MySQLStore({
      host: "127.0.0.1",
      database: "Project",
    }),
    resave: false,
    saveUninitialized: true,
    cookie: {
      maxage: 60 * 60 * 24,
    },
  })
);


app.use(function (req, res, next) {
  req.pool = dbconnectionpool;
  console.log(req.session);
  next();
});
app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));
console.log("maybe");




// app.get('/getaddress',req,res){
//   cookie_id=req.session.user
//   if (cookie_id==null||cookie_id==undefined){
//     res.status(401);
//     res.send();
//   }
//   else {
//     dbconnection.query("Select Home_address from user where UserId=?",[cookie_id], function(error, results, fields){
//       if (error) {
//         res.status(403);
//         res.send("Error Occured");
//         console.log(error);
//     }
//     else if (results[0].home_address!=null){
//       res.status(200);
//       res.send(results[0].Home_address);
//     }
//     else{
//       res.send("Address not provided");
//     }

//   });
// }
// }


app.post("/create_event", (req, res, next) =>{
  if( req.body.login_sta == false){
    console.log("Please log into your account first");
    res.send();
  }
  else{
    dbconnection.query(
      "INSERT into Events(Event_name, HostID, The_time, The_date, Event_description, Address_event) values(?, ?, ?, ?, ?,?)",
      [req.body.event_name, req.session.user , req.body.time, req.body.date, req.body.desc, req.body.location],
      function (error, results, fields) {
        if (error) {
          res.status(403);
          res.send("Cannot Add new event");
          console.log(error);
        } else {
          console.log("successful");
          res.redirect('/');
        }
    });
  }

});

app.get("/showEvents", (req,res)=>{
  if (req.session.user==null){
    console.log()
    res.send("Need to login to see event list");
  }
  else{
  dbconnection.query("select * from Events where HostID=?",[req.session.user], function(error, results, fields){
    if (error){
      console.log(error);
      res.status(500);
      res.send("Error Occured");
    }else{
     res.json(rows);
    }
  });
  }
 });
 app.use("/calendar", calendarRouter);
 app.use("/auth", authRouter);
 app.use("/mail", mailRouter);
module.exports = app;
