CREATE DATABASE Project;

USE Project;

CREATE TABLE user(
    UserId int NOT NULL AUTO_INCREMENT,
    Full_name varchar(40) NOT NULL,
    Email varchar(40) NOT NULL,
    Admin_permission tinyint(4) NOT NULL,
    hash varchar(200),
    salt varchar(200),
    Home_address varchar(200),
    google_token tinyint(4),
    PRIMARY KEY (UserID)
);
CREATE TABLE Events(
    EventID int NOT NULL AUTO_INCREMENT,
    Event_name varchar(255),
    HostID int NOT NOT NULL,
    The_time time NOT NULL,
    The_date date NOT NULL,
    Event_description text,
    Address_event varchar(255) NOT NULL,
    PRIMARY KEY (EventID),
    FOREIGN KEY (HostID) REFERENCES user(UserID)
);

CREATE TABLE Event_Record(
    ParticipantID int,
    EventID int,
    FOREIGN KEY (ParticipantID) REFERENCES user(UserID),
    FOREIGN KEY (EventID) REFERENCES Events(EventID)
);

